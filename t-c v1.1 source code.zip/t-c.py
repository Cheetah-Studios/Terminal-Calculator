#!/usr/bin/env python3

first_time = True  # Flag to track if it's the first input
yesno = "n"
memory = 0
memory_first_time = False

def show_welcome_sceen():
    print("==================================================\n"
        "|                                                |\n"
        "|  Hello and Welcome to the Terminal Calculator  |\n"
        "|                    or T-C                      |\n"
        "|                                                |\n"
        "|              by Cheetah Studios                |\n"
        "|                                                |\n"
        "==================================================\n"
        " ")
def show_command_info():
    print("to add use '+' to subtract use '-' \n"
    "to divide use '/' to multiply use '*' \n"
    "and to quit use 'q' and 'M', to use the last result :\n"
    "use the command 'version' to see the version number\n"
    " ")

def Error_101(): #no number in memory yet
    print("Error_101! You have not yet performed a calculation, so there is no number in memory yet.\n")

def Error_102(): #if an invalid command is used at the start like A, B, or 123
    print("Error_102! invalid operation. Please enter a valid option\n")

def Error_103(): #error of when Division by zero
    print("Error_103! Division by zero is not allowed.")

def Error_104(): # if an invalid input is entered, like A, B, or C
    print("Error_104! Invalid input. Please enter numeric values.")

def TC_version(): #shows the app version
    print("version = 1.1 ")

show_welcome_sceen()
while True:
    if first_time:
        whatis = input("What do you want to do, for info on what you can do type 'help' :")
        first_time = False  # Set flag to False after the first input
    else:
        whatis = input("What do you want to do next? :")
    
    if whatis.upper() == "VERSION":
        TC_version()
        continue 
    
    if whatis.upper() not in ["+", "-", "/", "*", "M", "HELP", "Q", "VERSION"]:
        Error_102()
        continue    # Restart the loop if the input is invalid
    
    if memory_first_time == False and whatis.upper() == "M":
        Error_101()
        first_time = False
        continue
        
    if whatis.upper() == "HELP":
        show_command_info()
        continue

    if whatis.upper() == "Q":
        print("Goodbye")
        break   # Exit the loop if the user enters 'Q'
    
    try:
        if whatis.upper() == "M" and memory_first_time == True:
            yesno = input(
                f"You have chosen to use the last result. The last result was: {memory}\nDo you want to use it? (Y/n): ")
            print(" ")

            if yesno.upper() == "Y":
                whatis = input("What do you want to do with it?, +, -, /, *, :")
                num1 = memory
                num2 = float(input("Enter the next number :"))
            elif yesno.upper() == "N":
                continue

        else:
            num1 = float(input("Enter a number :"))
            num2 = float(input("Enter the next number :"))

        if whatis == "+":
            result = num1 + num2
        elif whatis == "-":
            result = num1 - num2
        elif whatis == "/":
            while num2 == 0:  # Check before performing division by zero
                Error_103()
                num2 = float(input("Enter a number that is not zero: "))
            result = num1 / num2
        elif whatis == "*":
            result = num1 * num2

        print(num1, whatis, num2, "=", result)
        memory = result  # Store the result in memory for later use
        memory_first_time = True

    except ValueError:  # if an invalid input is entered, like A, B, or C
        Error_104()

# Terminal Calculator/T-C by Cheetah Studios
# T-C is short for Terminal Calculator
# Original creator: S,Lourens. dev name KoolTom123.
#
#if you make a new version of this file,
#add your name below. !DO NOT REMOVE! existing names.
#--------------------------------------------------------------------
#Contributors / Modders.
#